#!/bin/sh
sudo mkdir -p/var/log/microdom
sudo chmod 0777 /var/log/microdom

sudo ln -s ../sites-available/proxy-ssl-microdom-abm.conf /etc/apache2/sites-enabled/001-proxy-ssl-microdom-abm.conf

echo "==== Instalando modulos de apache ===="
sudo a2enmod ssl proxy proxy_http proxy_balancer lbmethod_byrequests headers
sudo systemctl restart apache2

echo "==== Servicio microdom ===="
echo "Stop..."
docker stop microdom
sleep 1
echo "Remove..."
docker rm microdom
sleep 1
echo "Update & Start..."
docker pull ghcr.io/wpirri/microdom:latest
docker run -it \
  -d --restart unless-stopped \
  -e DBUSER=dompi_web \
  -e DBPASSWORD=dompi_web \
  -e DBHOST=192.168.10.5 \
  -e DBNAME=DB_DOMPIWEB \
  --name microdom \
  -v /etc/microdom.conf:/app/etc/microdom.conf \
  -v /var/log/microdom:/app/logs \
  -v /var/lib/microdom/html:/app/html \
  -v /var/lib/microdom/download:/app/download \
  -p 8080:8080 \
  ghcr.io/wpirri/microdom:latest

echo "==== Servicio microdom-task ===="
echo "Stop..."
docker stop microdom-task
sleep 1
echo "Remove..."
docker rm microdom-task
sleep 1
echo "Update & Start..."
docker pull ghcr.io/wpirri/microdom-task:latest
docker run -it \
  -d --restart unless-stopped \
  -e DBUSER=dompi_web \
  -e DBPASSWORD=dompi_web \
  -e DBHOST=192.168.10.5 \
  -e DBNAME=DB_DOMPIWEB \
  --name microdom-task \
  -v /etc/microdom.conf:/app/etc/microdom.conf \
  -v /var/log/microdom:/app/logs \
  -p 8081:8081 \
  ghcr.io/wpirri/microdom-task:latest

echo "==== Servicio microdom-abm ===="
echo "Stop..."
docker stop microdom-abm
sleep 1
echo "Remove..."
docker rm microdom-abm
sleep 1
echo "Update & Start..."
docker pull ghcr.io/wpirri/microdom-abm:latest
docker run -it \
  -d --restart unless-stopped \
  -e DBUSER=dompi_web \
  -e DBPASSWORD=dompi_web \
  -e DBHOST=192.168.10.5 \
  -e DBNAME=DB_DOMPIWEB \
  --name microdom-abm \
  -v /etc/microdom.conf:/app/etc/microdom.conf \
  -v /var/log/microdom:/app/logs \
  -v /var/lib/microdom/html:/app/html \
  -v /var/lib/microdom/download:/app/download \
  -p 8082:8082 \
  ghcr.io/wpirri/microdom-abm:latest
